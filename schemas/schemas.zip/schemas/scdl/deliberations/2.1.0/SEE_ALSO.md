La spécification du modèle de données peut être utilement complétée par les documents suivants :

* Exemple de fichier
* [Schéma de validation](https://git.opendatafrance.net/scdl/deliberations/blob/master/schema.json)
* [Documentation générée à partir du schéma](https://scdl.opendatafrance.net/docs/schemas/scdl-deliberations.html)

Pour poser une question, commenter, faire un retour d’usage ou contribuer à l’amélioration du modèle de données, vous pouvez :

* adresser un message à [scdl@opendatafrance.email](mailto:scdl@opendatafrance.email?subject=Délibérations)
* ouvrir un ticket sur le [dépôt GitLab d’OpenDataFrance](https://git.opendatafrance.net/scdl/deliberations/issues/new)
