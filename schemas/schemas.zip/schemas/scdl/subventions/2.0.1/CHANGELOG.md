---
permalink: /scdl/subventions/latest/changelog.html
redirect_from: /scdl/subventions/2.0.1/changelog.html
title: CHANGELOG de Subventions
version: 2.0.1
---

# Changelog

## 2.0.1

Changements internes :
- utilisation des [métadonnées standardisées](https://github.com/frictionlessdata/specs/blob/master/specs/patterns.md#table-schema-metadata-properties)


## 2.0.0

- ajout du fichier `CHANGELOG.md`
- dans `schema.json`:
  - ajout de la clef `updated`
  - ajout des exemples (propriété `examples`)
  - amélioration des titres, descriptions et exemples
  - suppression des "required": false
  - changement de l'intervalle de valeur pour le champ `pourcentageSubvention`
  - ajout des custom-checks

## 1.1