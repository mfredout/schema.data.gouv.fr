---
permalink: /scdl/equipements/latest/changelog.html
redirect_from: /scdl/equipements/0.1.1/changelog.html
title: CHANGELOG de Équipements
version: 0.1.1
---

# Changelog

## 0.1.1

Changements internes :
- utilisation des [métadonnées standardisées](https://github.com/frictionlessdata/specs/blob/master/specs/patterns.md#table-schema-metadata-properties)

## 0.1.0

- version initiale