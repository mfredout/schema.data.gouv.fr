---
permalink: /scdl/equipements/0.1.0.html
redirect_from: null
title: Equipements
version: 0.1.0
---

# Schéma relatif aux équipements collectifs publics d'une collectivité